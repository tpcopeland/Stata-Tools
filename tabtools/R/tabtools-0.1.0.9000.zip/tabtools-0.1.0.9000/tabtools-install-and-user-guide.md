# tabtools for R: installation and user guide

**Version 0.1.0.9000** (pre-release) | 2 October 2026 | Timothy P Copeland, Karolinska Institutet

tabtools makes the tables of a clinical or epidemiological paper:

- a Table 1 of baseline characteristics
- regression tables
- incidence-rate tables, and incidence rates beside hazard ratios
- treatment effects and margins
- inverse-probability-weight diagnostics

Every table prints in the R console. It can also be written to Excel, Word, HTML, Markdown and CSV with the same rows, labels, indented category levels and Reference rows in each format. It is the R version of the Stata `tabtools` commands, but you do not need to know Stata to use it.

This is a pre-release version, shared before the package is public. Please report anything that looks wrong (see [Problems and questions](#problems-and-questions)).

## What you received

| File | What it is |
|---|---|
| `windows-R4.6/tabtools_0.1.0.9000.zip` | The package for Windows with R 4.6 |
| `windows-R4.5/tabtools_0.1.0.9000.zip` | The package for Windows with R 4.5 |
| `mac-R4.6/tabtools_0.1.0.9000.tgz` | The package for Apple Silicon Macs (M1 and later) with R 4.6 |
| `source/tabtools_0.1.0.9000.tar.gz` | The package as source code, for any other system or R version (needs a compiler; see [Installing from source](#installing-from-source)) |
| `tabtools-install-and-user-guide.docx` | This guide |
| `tabtools-syntax.md` | A guide for AI assistants (ChatGPT, Claude, Copilot and so on); see [Using tabtools with an AI assistant](#using-tabtools-with-an-ai-assistant) |

You need only one of the package files. Do not unzip or unpack it: R installs it as it is.

## Which file to use

Run this in R to see your version of R:

```r
R.version.string
```

- **Windows with R 4.6.x or 4.5.x:** use the matching file in `windows-R4.6` or `windows-R4.5`.
- **Mac with Apple Silicon (M1, M2, M3, M4 and later) and R 4.6.x:** use the file in `mac-R4.6`. To check your chip, open the Apple menu > About This Mac.
- **Anything else** (an older R, an Intel Mac, Linux): either update R from <https://cran.r-project.org> and use a file above, or [install from source](#installing-from-source).

A ready-made file works only with the R version it was made for: a file for R 4.6 does not work with R 4.5, and the other way round. tabtools needs R 4.1.0 or later. RStudio is optional but convenient.

## Installing on Windows or a Mac

1. Save the package file somewhere you can find it, for example your Downloads folder.
2. In R or RStudio, install the four packages tabtools needs, which come from CRAN:

```r
install.packages(c("broom.helpers", "cli", "openxlsx2", "withr"))
```

3. Install tabtools from the file. `file.choose()` opens a file browser, where you pick the file you saved:

```r
# Windows
install.packages(file.choose(), repos = NULL, type = "win.binary")

# Mac
install.packages(file.choose(), repos = NULL, type = "binary")
```

Alternatively, type the file's location in place of `file.choose()`, for example `"C:/Users/yourname/Downloads/tabtools_0.1.0.9000.zip"` (with forward slashes) on Windows or `"~/Downloads/tabtools_0.1.0.9000.tgz"` on a Mac.

## Installing from source

Use this route for any system or R version without a ready-made file. tabtools contains a small amount of C code, so R compiles it during installation. That needs a compiler, which takes a few minutes to set up once:

- **Windows:** install **Rtools** from <https://cran.r-project.org/bin/windows/Rtools/>. Pick the version that the page lists for your version of R, and accept the default options. Then restart R.
- **macOS:** open the Terminal app and run `xcode-select --install`, then follow the prompts. If it says the command line tools are already installed, you are done.
- **Linux:** install your distribution's R development package, for example `sudo apt install r-base-dev` on Ubuntu or Debian.

If you already install R packages "from source", you have this set up already. Then, in R:

```r
install.packages("remotes")   # once; skip if you already have it
remotes::install_local(file.choose())   # pick source/tabtools_0.1.0.9000.tar.gz
```

`remotes::install_local()` installs the packages tabtools needs from CRAN and then compiles and installs tabtools. If it asks whether to update other packages, answering "None" (or 3) is fine.

## Checking that it worked

```r
library(tabtools)
packageVersion("tabtools")   # should print 0.1.0.9000
```

## Optional packages

tabtools itself needs only the four packages above. Some features use other packages, which you install only if you need them:

| For | Install |
|---|---|
| Word tables | `flextable` and `officer` |
| HTML and Quarto tables | `gt` |
| Cox and other survival models, rate tables with hazard ratios | `survival` |
| Treatment effects and margins with `effecttab()` | `marginaleffects` |
| Reading Stata `.dta` files | `haven` |
| Mixed models | `lme4` (or `glmmTMB`, `nlme`) |
| IPTW weights | `WeightIt` |

A common set in one line:

```r
install.packages(c("flextable", "officer", "gt", "survival", "haven", "marginaleffects"))
```

## Your first tables

This example uses a dataset that comes with R. Paste it into R to see a Table 1 and a regression table:

```r
library(tabtools)

d <- mtcars
d$am <- factor(d$am, 0:1, c("Automatic", "Manual"))
attr(d$mpg, "label") <- "Miles per gallon"
attr(d$cyl, "label") <- "Cylinders"
attr(d$vs, "label") <- "Straight engine"

table1_tc(d, by = "am", vars = c(mpg = "contn %5.1f", cyl = "cat", vs = "bin"),
          smd = TRUE)

fit1 <- glm(breaks ~ wool, family = poisson, data = warpbreaks)
fit2 <- glm(breaks ~ wool + tension, family = poisson, data = warpbreaks)
regtab(fit1, fit2, models = c("Crude", "Adjusted"), stats = "n")
```

In `vars`, each entry names a column and how to summarise it:

- `contn` gives the mean ± SD; `%5.1f` sets one decimal.
- `conts` gives the median and quartiles.
- `cat` gives counts and column percentages for each level.
- `bin` gives the count of 1s.

Row labels come from each column's `"label"` attribute, and `smd = TRUE` adds standardized mean differences. `regtab()` chooses the effect measure from the model: incidence rate ratios for a Poisson model, odds ratios for a logistic one, hazard ratios for a Cox model.

Three habits make the tables read well:

- **Make categorical variables factors.** The level order is the row order, and the first level is the Reference row in regression tables.
- **Keep outcome and event indicators numeric 0/1,** not factors.
- **Give columns labels** with `attr(d$age, "label") <- "Age (years)"`. Data read from Stata with `haven` already have them. Set labels after making factors and subsets, because `factor()` and subsetting drop them.

### Saving tables to files

```r
t2 <- regtab(fit1, fit2, models = c("Crude", "Adjusted"),
             xlsx = "tables.xlsx", sheet = "Table 2")
t2   # a command that writes a file does not print the table: print it like this

# Word
flextable::save_as_docx(flextable::as_flextable(t2), path = "table2.docx")
```

Several tables can go into one Excel workbook, each with its own `sheet =`. `csv = "table.csv"` and `markdown = "table.md"` work the same way as `xlsx =`. Files are saved in R's working directory; `getwd()` shows where that is.

## Where to read next

The package includes five guides (vignettes). `browseVignettes("tabtools")` opens a list of them in your web browser. To open one directly:

| Command | What it covers | Read it if |
|---|---|---|
| `vignette("tabtools")` | Get started: a Table 1 and a regression table from start to finish, written to Excel, CSV, Markdown and Word | Read this first |
| `vignette("regression-tables", package = "tabtools")` | The supported models and their effect measures, choosing and labelling rows, standard errors, the rates-and-hazard-ratios Table 2, and models regtab does not support | You make regression tables |
| `vignette("weighted-analyses", package = "tabtools")` | IPTW and marginal structural models: balance tables, weight diagnostics with `wttab()`, robust and clustered variances, treatment effects with `effecttab()` | You use propensity scores or weights |
| `vignette("coming-from-stata", package = "tabtools")` | Option-by-option translation from the Stata commands, and every deliberate difference | You used `table1_tc` or `regtab` in Stata |
| `vignette("compared-with-gtsummary", package = "tabtools")` | The same Table 1 and Table 2 made with gtsummary and with tabtools | You know gtsummary |

The vignettes also mention `remotes::install_github()` and a file called `tabtools_0.1.0.tar.gz`. Those instructions are for when the package is public; use this guide's instructions until then.

Every function has a help page listing all of its arguments, with examples: `?table1_tc`, `?regtab` and so on. `help(package = "tabtools")` lists them all.

### The main functions

| Function | What it makes |
|---|---|
| `table1_tc()` (also called `desctab()`) | Table 1: baseline characteristics by group, with tests, SMDs, weights and small-cell suppression |
| `regtab()` | Regression table of one or more fitted models, side by side |
| `regtab_uv()` | One univariable model per covariate, as one `regtab()` column |
| `tt_mi()` | Multiply imputed fits, pooled by Rubin's rules, for `regtab()` |
| `tt_rates()`, `stratetab()` | Events, person-time and incidence rates per group, and their table |
| `hrcomptab()`, `comptab()` | Cohort-study Table 2 (rates beside hazard ratios); selected rows of several model tables |
| `effecttab()` | Treatment effects and margins from marginaleffects results |
| `wttab()` | Distribution and effective sample size of inverse probability weights |
| `puttab()`, `stacktab()` | Style any data frame as a sheet; assemble several tables into one sheet |
| `tt_merge()`, `tt_stack()` | Put tables side by side, or one under another |
| `tt_write_xlsx()`, `tt_write_csv()`, `tt_write_markdown()` | Write an existing table to a file |
| `flextable::as_flextable()`, `tt_as_gt()` | Convert a table for Word, or for HTML and Quarto |
| `tt_as_factor()` | Turn Stata value-labelled columns into factors |
| `tabtools_options()` | Default font, border style, digits and colours |

## Using tabtools with an AI assistant

`tabtools-syntax.md` is a guide written for AI assistants. It describes every function, its arguments, worked recipes and common mistakes, so the assistant writes correct tabtools code instead of guessing.

1. Start a new chat and attach or paste `tabtools-syntax.md`.
2. Add a **data dictionary**: variable names, labels, types and factor levels. Do not add the data itself. The end of `tabtools-syntax.md` shows how to make a dictionary in R without any row-level values.
3. Describe the tables you want, for example: "a Table 1 by treatment group with SMDs, then crude and adjusted Cox models for death, written to tables.xlsx".

**Never paste or upload individual-level data into an AI chat.** Patient data and other sensitive data must stay on approved systems; follow your institution's rules on using AI tools. Small counts in a dictionary can also identify people, and the guide explains how to leave them out.

The same file is installed with the package, so you can find it on your computer with `system.file("llm", "tabtools-syntax.md", package = "tabtools")`. Its first code block shows `remotes::install_github()`, which will only work once the package is public; if the assistant suggests reinstalling that way, ignore it.

## Updating or removing

To install a newer version you receive, install the new file the same way; it replaces the old version. Restart R afterwards (in RStudio: Session > Restart R). If you update R itself to a new minor version (say 4.5 to 4.6), reinstall tabtools with the file for the new version.

To remove tabtools:

```r
remove.packages("tabtools")
```

## Troubleshooting

| Message or problem | What to do |
|---|---|
| `there is no package called 'broom.helpers'` (or cli, openxlsx2, withr) | Install the four required packages (step 2 of the installation), then load tabtools again. |
| Warning: `package 'tabtools' was built under R version 4.5.3` (or 4.6.1) | Harmless when the first two numbers match your R (4.5 or 4.6): the file was made with a slightly newer patch release. Updating R removes it. |
| An error mentioning `built under R version`, or `is not a valid installed package` | The file does not match your R version. Check `R.version.string` and use the matching file, or [install from source](#installing-from-source). |
| `cannot open file ... No such file or directory` | The path to the file is wrong. Use `file.choose()` in place of the path. |
| `package 'tabtools' is not available` | `install.packages("tabtools")` looks on CRAN, where tabtools is not yet published. Install from the file as above. |
| Source install on Windows: `WARNING: Rtools is required to build R packages`, or `make: not found` | Install Rtools (see [Installing from source](#installing-from-source)), restart R, and try again. |
| Source install on macOS: `xcrun: error: invalid active developer path`, or `clang: command not found` | Run `xcode-select --install` in Terminal, then try again. |
| Source install on macOS: `warning: unknown warning group '-Wfixed-enum-extension'` | This is harmless: it comes from older versions of R with newer Apple compilers, and installation still succeeds. Updating R removes it. |
| A table is not written to Excel or Word | Check `getwd()` for where the file went, and close the file if it is open in Excel or Word. |
| An old version still loads after updating | Restart R, then run `packageVersion("tabtools")`. |

## Problems and questions

Contact Timothy Copeland (timothy.copeland@ki.se). Please include:

- the code that produced the problem, ideally on a built-in or simulated dataset rather than your study data
- the full error message
- the output of `sessionInfo()`
